package tk.mybatis.simple.mapper;

public interface RolePrivilegeMapper {

}
